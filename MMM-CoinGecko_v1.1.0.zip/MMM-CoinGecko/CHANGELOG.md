# Changelog

## 1.1.0
- Added multi-period % change columns (configurable via `changePeriods`).
- Added optional column headers (`showHeaders`).
- Added up/down/neutral coloring for change values.
- Improved no-wrap layout to prevent table word wrapping.

## 1.0.0
- Initial release.
