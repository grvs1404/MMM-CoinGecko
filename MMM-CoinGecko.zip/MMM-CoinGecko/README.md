# MMM-CoinGecko

MagicMirror² module to display cryptocurrency prices using CoinGecko.

## Configuration

```js
{
  module: "MMM-CoinGecko",
  position: "top_right",
  config: {
    coins: ["bitcoin", "ethereum"],
    vsCurrency: "usd"
  }
}
```
